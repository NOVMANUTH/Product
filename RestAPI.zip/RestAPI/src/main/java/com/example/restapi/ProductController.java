package com.example.restapi;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/products")
public class ProductController {

    // Dummy database (Replace with database integration)
    private Map<Long, Product> products = new HashMap<>();

    @PostMapping
    public ResponseEntity<Void> addProduct(@RequestBody Product product) {
        // Logic to add a product (e.g., save to database)
        products.put(product.getId(), product);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        // Logic to retrieve product by ID
        Product product = products.get(id);
        if (product != null) {
            return ResponseEntity.ok(product);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        // Logic to retrieve all products
        List<Product> productList = new ArrayList<>(products.values());
        return ResponseEntity.ok(productList);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateProduct(@PathVariable Long id, @RequestBody Product product) {
        // Logic to update a product by ID
        if (products.containsKey(id)) {
            products.put(id, product);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
